var socket = io.connect('http://192.168.63.225:8080', { 'forceNew': true });
//
socket.on('messages', function (data) {
  console.log(data);
  render(data);
})

function render(data) {
  var html = data.map(function (elem, index) {
    let html_string = string_expresion(elem.text);
    return (`<div class="container-elements">
              <strong class="autor">${elem.author}</strong> 
              <p class="message">${elem.text}</p>
            </div> ${html_string}`);

  }).join(" ");

  document.getElementById('messages').innerHTML = html;
}

function addMessage(e) {
  var message = {
    author: document.getElementById('username').value,
    text: document.getElementById('texto').value
  };

  socket.emit('new-message', message);
  return false;
}

let string_expresion = (date) => {
  let numerosmayusculas, numerosnovovales, numerospalabras, numerosvocales, numerosnumeros;

  let mayusculas = date.match(/\b[A-Z]/g, "");
  let novovales = date.match(/[^aeiou\W\d]\b/g, "");
  let palabras = date.match(/[^\s\d]+/g, "");
  let vocales = date.match(/[aeiou]/g, "");
  let numeros = date.match(/[\d]/g, "");

  if (mayusculas === null) {
    numerosmayusculas = 0;
  } else {
    numerosmayusculas = mayusculas.length;
  }
  if (novovales === null) {
    numerosnovovales = 0;
  } else {
    numerosnovovales = novovales.length;
  }
  if (palabras === null) {
    numerospalabras = 0;
  } else {
    numerospalabras = palabras.length;
  }
  if (vocales === null) {
    numerosvocales = 0;
  } else {
    numerosvocales = vocales.length;
  }
  if (numeros === null) {
    numerosnumeros = 0;
  } else {
    numerosnumeros = numeros.length;
  }

  
  return `<p class="results"> Numero de mayusculas: ${numerosmayusculas}  <br> 
          No vocales al final: ${numerosnovovales}   <br> 
          Palabras encontradas: ${numerospalabras}   <br>   
          Vocales encontradas: ${numerosvocales}     <br>  
          Numeros encontrados: ${numerosnumeros}</p>`;
          
}

